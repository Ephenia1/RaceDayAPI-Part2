# RaceDayAPI — Part 2

ASP.NET Core Web API for the RaceDay event system. It uses Entity Framework Core Code First, SQL Server, session-based authentication, role checks, and Swagger.

## Prerequisites
- .NET 10 SDK (the project targets `net10.0`)
- SQL Server LocalDB (installed with Visual Studio) or SQL Server instance
- EF Core CLI: `dotnet tool install --global dotnet-ef --version 10.0.13`

## Configure SQL Server
The default connection string in `appsettings.json` uses LocalDB and creates/uses `RaceDayDB`:

`Server=(localdb)\MSSQLLocalDB;Database=RaceDayDB;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True`

If using another SQL Server instance, update `ConnectionStrings:DefaultConnection` accordingly. Do not commit real passwords or production connection strings.

## Create the database (Code First)
The previous migration was generated for SQLite and has been removed because it cannot be applied to SQL Server. From the folder containing `RaceDayAPI.csproj`, run:

```powershell
dotnet restore
dotnet tool install --global dotnet-ef --version 10.0.13
dotnet ef migrations add InitialSqlServerCreate
dotnet ef database update
dotnet run
```

Review the generated migration against the approved Part 1 ERD/SQL script before submitting. This project cannot verify schema equivalence without the Part 1 artifacts.

## Swagger
When running in Development, open the URL printed by `dotnet run` and append `/swagger` (for example `https://localhost:7000/swagger`). Use the same browser session/cookie for login and subsequent requests. Swagger's **Try it out** can exercise endpoints; for session-based auth, ensure the browser retains the session cookie.

## Roles
- **Organiser:** create events; update/delete only their own events; create categories and link categories to their own events; view enrolments for their own events; record results for enrolments belonging to their own events.
- **Participant:** view events/categories; enrol in events; view/update their own profile; view their own enrolments and results.
- Both roles can view their own profile and update only personal profile fields.

Registration accepts `Organiser` or `Participant` as requested in the brief. For a real deployment, organiser registration should be approved/invited rather than publicly self-selected.

## GitHub Actions
The workflow in `.github/workflows/dotnet.yml` restores, builds, and runs tests on each push and pull request. CI builds the API; database integration tests require a configured SQL Server and are not represented as passing by this workflow.

## Submission checklist
- [ ] Confirm tables and relationships against Part 1 ERD/SQL script.
- [ ] Create and apply SQL Server migration locally.
- [ ] Run and verify all endpoints in Swagger.
- [ ] Add/complete tests for authentication, role restrictions, event ownership, enrolment and results.
- [ ] Capture a genuine green GitHub Actions build screenshot after a successful run.
- [ ] Add the actual unlisted YouTube presentation URL.
- [ ] Make at least 20 meaningful commits from your own GitHub account; do not fabricate commit history.

## API endpoint overview
- `POST /api/Auth/register`, `POST /api/Auth/login`, `POST /api/Auth/logout`
- `GET /api/Users/me`, `PUT /api/Users/me`
- `GET /api/Events`, `GET /api/Events/{id}`, `POST /api/Events`, `PUT /api/Events/{id}`, `DELETE /api/Events/{id}`
- `GET /api/Categories`, `POST /api/Categories`, `POST /api/Categories/event-category`, `GET /api/Categories/event/{eventId}`
- `POST /api/Enrolments`, `GET /api/Enrolments/event/{eventId}`, `GET /api/Enrolments/my`
- `POST /api/Results`, `GET /api/Results/my`, `GET /api/Results/event/{eventId}`
